Description of Present On Admission (POA) files

List of Present On Admission (POA) exempt codes, consistent with the current FY2016 guidelines (35,239 codes). 
POAexemptCodes2016.xlsx (Excel spreadsheet)
POAexemptCodes2016.txt (tab delimited text)
These files have three fields, as below.
Order: a number as text (with leading zeros), corresponding to the code ordering in the classification, and in the descriptions list file.
POAexemptCode: the ICD-10-CM code that is exempt from POA reporting.
Description: the long title for the ICD-10-CM code, corresponding to the descriptions list file.

List of codes added to the current FY2016 POA exempt list, from the previous list, to properly match the guidelines (1628 codes).
POAexemptAddCodes2016.xlsx (Excel spreadsheet)
POAexemptAddCodes2016.txt (tab delimited text)
These files have two fields, as below.
POA-exm-Add-code: the ICD-10-CM code that should be added to the previously available list, to properly match the guidelines. 
Description: the long title for the ICD-10-CM code, corresponding to the descriptions list file.

List of codes deleted from the previous POA exempt list, to create the current FY2016 POA exempt list, to properly match the guidelines (731 codes).
POAexemptDelCodes2016.xlsx (Excel spreadsheet)
POAexemptDelCodes2016.txt (tab delimited text)
These files have two fields, as below.
POA-exm-Del-code: the ICD-10-CM code that should be removed from the previously available list, to properly match the guidelines. 
Description: the long title for the ICD-10-CM code, corresponding to the descriptions list file.
